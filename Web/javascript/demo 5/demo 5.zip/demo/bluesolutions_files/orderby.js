	<!--
	  function orderby(value, asc)
	  {
		document.forms["webform"].orderby.value = value;
		document.forms["webform"].sortorder.value = asc;
		document.forms["webform"].submit()
	  }
	  function page(value)
	  {
		document.forms["webform"].page.value = value;
		document.forms["webform"].submit()
	  }	  
	// -->
